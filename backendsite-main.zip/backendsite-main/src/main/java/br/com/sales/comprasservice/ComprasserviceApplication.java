package br.com.sales.comprasservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComprasserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComprasserviceApplication.class, args);
	}

}
