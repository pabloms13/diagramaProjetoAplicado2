package br.com.sales.comprasservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComprasserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
